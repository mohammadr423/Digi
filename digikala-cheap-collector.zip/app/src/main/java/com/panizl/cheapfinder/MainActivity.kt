package com.panizl.cheapfinder

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ExpandableListView
import android.widget.LinearLayout
import android.widget.SimpleExpandableListAdapter
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

data class Item(val id: Long, val title: String, val priceToman: Long, val category: String)

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val items = LinkedHashMap<Long, Item>()
    private var snapshot: List<Pair<String, List<Item>>> = emptyList()

    private lateinit var status: TextView
    private lateinit var maxInput: EditText
    private lateinit var list: ExpandableListView

    private fun w() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = "کالاهای ارزان دیجی‌کالا"
            textSize = 20f
            gravity = Gravity.CENTER
        }
        maxInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("300000")
            hint = "سقف قیمت (تومان)"
        }
        val start = Button(this).apply { text = "شروع" }
        val stop = Button(this).apply { text = "توقف" }
        val export = Button(this).apply { text = "خروجی CSV" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(start, w())
        row.addView(stop, w())
        row.addView(export, w())

        status = TextView(this).apply { text = "آماده"; setPadding(0, 12, 0, 12) }
        list = ExpandableListView(this)

        root.addView(title)
        root.addView(maxInput)
        root.addView(row)
        root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        start.setOnClickListener { startCollect() }
        stop.setOnClickListener { running.set(false); setStatus("در حال توقف...") }
        export.setOnClickListener { exportCsv() }
        list.setOnChildClickListener { _, _, g, c, _ ->
            val it = snapshot[g].second[c]
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.digikala.com/product/dkp-${it.id}/")))
            true
        }

        loadSaved()
        refreshList()
        setStatus("آماده — ${items.size} کالا ذخیره شده")
    }

    // ---------- Collecting ----------

    private fun startCollect() {
        if (!running.compareAndSet(false, true)) return
        val maxToman = maxInput.text.toString().toLongOrNull() ?: 300000L
        val maxRial = maxToman * 10
        synchronized(items) { items.clear() }

        thread {
            try {
                setStatus("دریافت لیست دسته‌ها...")
                val cats = loadCategories()
                for ((ci, cat) in cats.withIndex()) {
                    if (!running.get()) break
                    var page = 1
                    var total = 1
                    while (page <= total && page <= 100 && running.get()) {
                        val url = "https://api.digikala.com/v1/categories/${cat.first}/search/" +
                            "?has_selling_stock=1&price%5Bmin%5D=1&price%5Bmax%5D=$maxRial&page=$page"
                        val data = fetchJson(url) ?: break
                        total = data.optJSONObject("pager")?.optInt("total_pages", 1) ?: 1
                        val arr = data.optJSONArray("products") ?: break
                        if (arr.length() == 0) break
                        for (i in 0 until arr.length()) {
                            val p = arr.getJSONObject(i)
                            val id = p.optLong("id")
                            if (id == 0L) continue
                            if (p.optString("status") != "marketable") continue
                            val price = p.optJSONObject("default_variant")
                                ?.optJSONObject("price")?.optLong("selling_price", 0L) ?: 0L
                            if (price <= 0L || price > maxRial) continue
                            synchronized(items) {
                                items[id] = Item(id, p.optString("title_fa"), price / 10, cat.second)
                            }
                        }
                        setStatus("${cat.second} (${ci + 1}/${cats.size}) — صفحه $page از $total — ${items.size} کالا")
                        page++
                        Thread.sleep(600)
                    }
                    save()
                }
                setStatus(if (running.get()) "پایان — ${items.size} کالا" else "متوقف شد — ${items.size} کالا")
            } catch (e: Exception) {
                setStatus("خطا: ${e.message}")
            } finally {
                running.set(false)
                save()
                ui.post { refreshList() }
            }
        }
    }

    private fun loadCategories(): List<Pair<String, String>> {
        val data = JSONObject(httpGet("https://api.digikala.com/v1/categories/")).getJSONObject("data")
        val arr = data.getJSONArray("categories")
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val code = c.optString("code")
            if (code.isNotEmpty()) out.add(code to c.optString("title_fa", code))
        }
        return out
    }

    private fun fetchJson(url: String): JSONObject? = try {
        JSONObject(httpGet(url)).optJSONObject("data")
    } catch (e: Exception) {
        setStatus("خطا: ${e.message}")
        null
    }

    private fun httpGet(u: String): String {
        repeat(4) { attempt ->
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36"
            )
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            if (code == 200) return c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            if (code == 429 || code >= 500) Thread.sleep(3000L * (attempt + 1))
            else throw RuntimeException("HTTP $code")
        }
        throw RuntimeException("تلاش مجدد ناموفق بود")
    }

    // ---------- UI ----------

    private fun setStatus(s: String) = ui.post { status.text = s }

    private fun fmt(n: Long) = NumberFormat.getInstance(Locale.US).format(n)

    private fun refreshList() {
        snapshot = synchronized(items) {
            items.values.groupBy { it.category }.toList()
                .map { (k, v) -> k to v.sortedBy { x -> x.priceToman } }
                .sortedByDescending { it.second.size }
        }
        val groups = snapshot.map { mapOf("n" to "${it.first} (${it.second.size})") }
        val children = snapshot.map { (_, l) ->
            l.map { mapOf("t" to it.title, "p" to "${fmt(it.priceToman)} تومان") }
        }
        list.setAdapter(
            SimpleExpandableListAdapter(
                this,
                groups, android.R.layout.simple_expandable_list_item_1,
                arrayOf("n"), intArrayOf(android.R.id.text1),
                children, android.R.layout.simple_expandable_list_item_2,
                arrayOf("t", "p"), intArrayOf(android.R.id.text1, android.R.id.text2)
            )
        )
    }

    // ---------- Storage ----------

    private fun save() {
        val arr = JSONArray()
        synchronized(items) {
            items.values.forEach {
                arr.put(JSONObject().put("id", it.id).put("t", it.title).put("p", it.priceToman).put("c", it.category))
            }
        }
        File(filesDir, "products.json").writeText(arr.toString())
    }

    private fun loadSaved() {
        val f = File(filesDir, "products.json")
        if (!f.exists()) return
        try {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items[o.getLong("id")] = Item(o.getLong("id"), o.getString("t"), o.getLong("p"), o.getString("c"))
            }
        } catch (_: Exception) {
        }
    }

    private fun exportCsv() {
        if (items.isEmpty()) {
            Toast.makeText(this, "داده‌ای نیست", Toast.LENGTH_SHORT).show()
            return
        }
        val sb = StringBuilder("\uFEFFid,category,title,price_toman,url\n")
        synchronized(items) {
            items.values.sortedWith(compareBy({ it.category }, { it.priceToman })).forEach {
                val t = it.title.replace("\"", "\"\"")
                val c = it.category.replace("\"", "\"\"")
                sb.append("${it.id},\"$c\",\"$t\",${it.priceToman},https://www.digikala.com/product/dkp-${it.id}/\n")
            }
        }
        val bytes = sb.toString().toByteArray(Charsets.UTF_8)
        val name = "digikala_cheap_products.csv"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                Toast.makeText(this, "ذخیره شد در Downloads", Toast.LENGTH_LONG).show()
            } else {
                val f = File(getExternalFilesDir(null), name)
                f.writeBytes(bytes)
                Toast.makeText(this, "ذخیره شد: ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "خطا: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
